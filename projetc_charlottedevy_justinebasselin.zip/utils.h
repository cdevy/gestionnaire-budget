#ifndef UTILS_H_INCLUDED
#define UTILS_H_INCLUDED

/*
Definit des fonctions utiles au projet
*/

long taille_double(double d);

long taille_long(long l);

void vider_buffer();

void traiter(char* chaine, int choix);

#endif
