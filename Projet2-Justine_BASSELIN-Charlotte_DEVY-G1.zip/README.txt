Justine BASSELIN
Charlotte DEVY

Pr�sentation du projet :

Notre application est un outil permettant de g�rer ses comptes. 
Au lancement de l'application, un menu s'ouvre. Entrer le chiffre associ� � l'action que vous souhaitez effectuer.
Vous avez acc�s � chaque compte de l'application, vous pouvez en cr�er, en supprimer et effectuer des actions sur ceux-ci.
Lorsque vous cr�ez un compte, vous devez fournir un num�ro de compte � 10 chiffres, un nom pour ce compte, vos nom et pr�nom, le nom de la banque, la localisation de la banque (ville) et un solde initial strictement sup�rieur � 0.

Apr�s avoir cr�� vos comptes, vous pouvez les visualiser gr�ce � la commande 2, consulter l'�tat de vos comptes gr�ce � la commande 3, c'est-�-dire consulter votre solde, ou encore fixer un seuil de d�pense maximal. A partir de la commande 4 vous pouvez importer vos relev�s bancaire et attribuer une cat�gorie et une sous-cat�gorie � chacune de vos op�rations. Enfin, en entrant la commande 5, vous pouvez acc�der � diff�rentes statistiques li�es � votre compte.
